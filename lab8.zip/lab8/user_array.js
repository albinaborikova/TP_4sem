export default class UserArray {
    _arr = []
  
    _compareById (a, b) {
      return a.id < b.id
    }
  
    getUsers (skip = 0, top = 10, filterConfig) {
      let res = []
      res = this._arr.filter((e) => (this._arr.indexOf(e) < skip + top && this._arr.indexOf(e) >= skip))
      if (filterConfig !== undefined) {
        res = res.filter((e) => {
          return e[Object.keys(filterConfig)[0]] === filterConfig[Object.keys(filterConfig)[0]]
        })
      }
      return res.sort(this._compareById)
    }
  
    getUser (id) {
      let res
      this._arr.forEach((e) => {
        if (e.id === id) res = e
      })
      return res
    }
  
    validateUser (user) {
      if (user.id == null || user.description == null || user.createdAt == null || 
        user.author == null || user.name == null || user.second_name == null || user.phone == null ||
         user.email == null || user.password == null) {
        return false
      }
      return true
    }
  
    addUser (user) {
      if (!this.validateUser(user)) {
        return false
      }
      this._arr.push(user)
      return true
    }
  
    editUser (id, user) {
      let index = -1
      this._arr.forEach((e) => {
        if (e.id === id) {
          index = this._arr.indexOf(e)
        }
      })
      if (index === -1) {
        return
      }
      for (const property in user) {
        this._arr.at(index)[property] = user[property]
      }
    }
  
    removeUser (id) {
      let indexToRemove = -1
      this._arr.forEach((e) => {
        if (e.id === id) {
          indexToRemove = this._arr.indexOf(e)
        }
      })
      if (indexToRemove > -1) {
        this._arr.splice(indexToRemove, 1)
      }
    }
  
    constructor (users) {
      users.forEach((e) => {
        if (this.validateUser(e)) {
          this._arr.push(e)
        }
      })
    }
  
    addAll (users) {
      users.forEach((e) => {
        if (this.validateUser(e)) {
          this._arr.push(e)
        }
      })
    }
  
    clear () {
      this._arr = []
    }
  }
  