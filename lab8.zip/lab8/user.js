class User {
    #id;
    #description;
    #createdAt;
    #author;
    #name;
    #second_name;
    #last_name;
    #phone;
    #email;
    #password;
    constructor(id, description, createdAt, author, name, second_name,last_name, phone, email, password, ){
        this.#id = id;
        this.#description = description;
        this.#createdAt = createdAt;
        this.#author = author;
        this.#name = name;
        this.#second_name = second_name;
        this.#last_name = last_name;
        this.#phone = phone;
        this.#password = password;
    }
}