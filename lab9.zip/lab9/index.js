import UserArray from './user_array.js'

const arr = new UserArray([{
  id: 0,
  description: 'banking',
  createdAt: new Date('2023-03-5T23:00:00'),
  author: 'borikova0',
  name: 'Albina',
  second_name: 'Alexandrovna',
  last_name: 'Borikova',
  phone: '+37593080203',
  email: 'albina.borikova@gmail.com',
  password: 'borikova2004'
}])

console.log('getUsers')
console.log(arr.getUsers(0, 1, { author: 'author0' }))
console.log('getUser')
console.log(arr.getUser(0))
console.log('validateUserTrue')
console.log(arr.validateUser({
  id: 0,
  description: 'banking',
  createdAt: new Date('2023-03-5T23:00:00'),
  author: 'borikova0',
  name: 'Albina',
  second_name: 'Alexandrovna',
  last_name: 'Borikova',
  phone: '+37593080203',
  email: 'albina.borikova@gmail.com',
  password: 'borikova2004'
}))
console.log('validateUserFalse')
console.log(arr.validateUser({
  id: 0,
  ddescription: 'banking',
  createdAt: new Date('2023-03-5T23:00:00'),
  author: 'borikova0',
  name: 'Albina',
  second_name: 'Alexandrovna',
  last_name: 'Borikova',
  phone: '+37593080203',
  email: 'albina.borikova@gmail.com',
  password: 'borikova2004'
}))

console.log('addUserTrue')
arr.addUser({
  id: 0,
  description: 'banking',
  createdAt: new Date('2023-03-5T23:00:00'),
  author: 'borikova0',
  name: 'Albina',
  second_name: 'Alexandrovna',
  last_name: 'Borikova',
  phone: '+37593080203',
  email: 'albina.borikova@gmail.com',
  password: 'borikova2004'
})
console.log(arr.getUsers())
console.log('addUserFalse')
arr.addUser({
  id: 0,
  description: 'banking',
  createdAt: new Date('2023-03-5T23:00:00'),
  author: 'borikova0',
  name: 'Albina',
  second_name: 'Alexandrovna',
  last_name: 'Borikova',
  phone: '+37593080203',
  email: 'albina.borikova@gmail.com',
  password: 'borikova2004'
})
console.log(arr.getUsers())
console.log('clear')
arr.clear()
arr.getUsers()
console.log('addAll')
arr.addAll([{
  id: 0,
  description: 'banking',
  createdAt: new Date('2023-03-5T23:00:00'),
  author: 'borikova0',
  name: 'Albina',
  second_name: 'Alexandrovna',
  last_name: 'Borikova',
  phone: '+37593080203',
  email: 'albina.borikova@gmail.com',
  password: 'borikova2004'
},
{
  id: 1,
  description: 'banking1',
  createdAt: new Date('2024-03-5T23:00:00'),
  author: 'borikova1',
  name: 'Albina1',
  second_name: 'Alexandrovna1',
  last_name: 'Borikova1',
  phone: '+37593080204',
  email: 'albina.borikova1@gmail.com',
  password: 'borikova2004.1'
},
{
  id: 2,
  description: 'banking2',
  createdAt: new Date('2025-03-5T23:00:00'),
  author: 'borikova2',
  name: 'Albina2',
  second_name: 'Alexandrovna2',
  last_name: 'Borikova2',
  phone: '+37593080205',
  email: 'albina.borikova2@gmail.com',
  password: 'borikova2004.2'
}])
console.log(arr.getUsers())
console.log('removeUser')
arr.removeUser(0)
console.log(arr.getUsers())
console.log('editUser')
arr.editUser(1, { description: 'newdesc', login: 'newlogin' })
console.log(arr.getUsers())
